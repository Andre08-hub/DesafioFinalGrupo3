package servicio;

import java.text.Normalizer;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import modelo.Paciente;

public class GestionEstablecimiento {
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private List<Paciente> pacientes = new ArrayList<>();

    public void registrarPaciente(Paciente p) { pacientes.add(p); }

    public boolean eliminarPaciente(String dni) {
        return pacientes.removeIf(p -> p.getDniDesencriptado().equals(dni));
    }

    public Optional<Paciente> buscarPacientePorDni(String dni) {
        // Uso de programación funcional (Streams)
        return pacientes.stream()
                .filter(p -> p.getDniDesencriptado().equals(dni))
                .findFirst();
    }

    public List<Paciente> getPacientes() { return pacientes; }

    /**
     * Búsqueda con Streams. Reglas:
     *  - No distingue mayúsculas ni tildes ("perez" encuentra "Pérez").
     *  - Se pueden escribir varias palabras, en cualquier orden: todas deben coincidir.
     *  - Cada palabra puede ser parcial ("1234" encuentra el DNI 12345678).
     *  - Texto vacío devuelve todos los pacientes.
     */
    public List<Paciente> buscarPacientes(String texto, CriterioBusqueda criterio) {
        CriterioBusqueda campoBuscado = (criterio == null) ? CriterioBusqueda.TODOS : criterio;

        List<String> terminos = Arrays.stream(normalizar(texto).split("\\s+"))
                .filter(t -> !t.isEmpty())
                .collect(Collectors.toList());

        return pacientes.stream()
                .filter(p -> {
                    String campo = textoBuscable(p, campoBuscado);
                    return terminos.stream().allMatch(campo::contains);
                })
                .collect(Collectors.toList());
    }

    /** Texto (ya normalizado) del paciente sobre el que se compara, según el criterio elegido. */
    private String textoBuscable(Paciente p, CriterioBusqueda criterio) {
        switch (criterio) {
            case DNI:    return p.getDniDesencriptado();
            case NOMBRE: return normalizar(p.getNombreCompleto());
            case SEGURO: return normalizar(p.getSeguro());
            case FECHA:  return fechasDeCitas(p);
            default:     return normalizar(String.join(" ",
                                p.getDniDesencriptado(),
                                p.getNombreCompleto(),
                                p.getSeguro(),
                                fechasDeCitas(p)));
        }
    }

    /** Todas las fechas de cita del paciente, en formato dd/MM/yyyy y separadas por espacio. */
    private String fechasDeCitas(Paciente p) {
        return p.getHistorial().stream()
                .map(a -> a.getFecha().format(FORMATO_FECHA))
                .collect(Collectors.joining(" "));
    }

    /** Pasa a minúsculas y quita las tildes. */
    private String normalizar(String texto) {
        if (texto == null) return "";
        return Normalizer.normalize(texto, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase()
                .trim();
    }
}
