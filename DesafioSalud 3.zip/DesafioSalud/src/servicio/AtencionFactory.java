package servicio;

import java.time.LocalDate;

import modelo.AtencionMedica;

/**
 * Factory para la creación de citas / atenciones médicas.
 */
public class AtencionFactory {
    public static AtencionMedica crearAtencion(String tipo, String diagnostico, String especialidad, String doctor, LocalDate fecha) {
        double costoBase = 0.0;
        switch (tipo) {
            case "CONSULTA": costoBase = 20.0; break;
            case "EMERGENCIA": costoBase = 50.0; break;
            case "CONTROL CRED": costoBase = 0.0; break;
        }
        return new AtencionMedica(tipo, diagnostico, especialidad, doctor, fecha, costoBase);
    }
}
