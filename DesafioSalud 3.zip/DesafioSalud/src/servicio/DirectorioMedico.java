package servicio;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import modelo.Doctor;

/**
 * Directorio de doctores del establecimiento, organizado por especialidad.
 * (Nombres ficticios para el proyecto.)
 */
public class DirectorioMedico {
    private final List<Doctor> doctores = new ArrayList<>();

    public DirectorioMedico() {
        // Medicina General
        doctores.add(new Doctor("Dr.",  "Carlos Quispe Rojas",       "Medicina General"));
        doctores.add(new Doctor("Dra.", "Lucía Fernández Díaz",      "Medicina General"));
        doctores.add(new Doctor("Dr.",  "Marco Vásquez Llamo",       "Medicina General"));
        // Pediatría
        doctores.add(new Doctor("Dra.", "Rosa Mendoza Tello",        "Pediatría"));
        doctores.add(new Doctor("Dr.",  "Julio Cabrera Núñez",       "Pediatría"));
        // Odontología
        doctores.add(new Doctor("Dr.",  "Hugo Alarcón Paredes",      "Odontología"));
        doctores.add(new Doctor("Dra.", "Patricia Salazar Cueva",    "Odontología"));
        // Ginecología
        doctores.add(new Doctor("Dra.", "Elena Ramírez Cotrina",     "Ginecología"));
        doctores.add(new Doctor("Dra.", "Karina Huamán Silva",       "Ginecología"));
        // Psicología
        doctores.add(new Doctor("Lic.", "Daniel Ortiz Barrantes",    "Psicología"));
        doctores.add(new Doctor("Lic.", "María Fernanda Cruz Vega",  "Psicología"));
    }

    /** Especialidades disponibles, sin repetir y en orden de registro. */
    public List<String> getEspecialidades() {
        return doctores.stream()
                .map(Doctor::getEspecialidad)
                .distinct()
                .collect(Collectors.toList());
    }

    /** Doctores que atienden una especialidad. */
    public List<Doctor> getDoctoresPorEspecialidad(String especialidad) {
        return doctores.stream()
                .filter(d -> d.getEspecialidad().equals(especialidad))
                .collect(Collectors.toList());
    }

    /** Indica si el doctor (nombre mostrado en pantalla) atiende la especialidad indicada. */
    public boolean atiendeEspecialidad(String nombreDoctor, String especialidad) {
        return doctores.stream()
                .anyMatch(d -> d.getNombreConTitulo().equals(nombreDoctor)
                            && d.getEspecialidad().equals(especialidad));
    }
}
