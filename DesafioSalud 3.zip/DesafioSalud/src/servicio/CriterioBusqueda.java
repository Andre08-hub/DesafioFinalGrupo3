package servicio;

/**
 * Campos por los que se puede filtrar la tabla de pacientes.
 */
public enum CriterioBusqueda {
    TODOS("Todos los campos"),
    DNI("DNI"),
    NOMBRE("Nombre"),
    SEGURO("Seguro"),
    FECHA("Fecha de cita");

    private final String etiqueta;

    CriterioBusqueda(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    @Override
    public String toString() {
        return etiqueta;
    }
}
