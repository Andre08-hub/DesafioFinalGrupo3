package servicio;

import java.time.LocalDate;
import java.util.Arrays;

import modelo.AtencionMedica;
import modelo.Paciente;

public class RegistroAtencionService {
    /** Tipos de seguro permitidos (los mismos que ofrece el formulario de registro). */
    public static final String[] SEGUROS_VALIDOS = {"SIS", "EsSalud", "Particular"};

    private GestionEstablecimiento gestion;
    private DirectorioMedico directorio;

    public RegistroAtencionService(GestionEstablecimiento gestion) {
        this(gestion, new DirectorioMedico());
    }

    public RegistroAtencionService(GestionEstablecimiento gestion, DirectorioMedico directorio) {
        this.gestion = gestion;
        this.directorio = directorio;
    }

    // Paradigma estructurado para validaciones
    public void registrarNuevoPaciente(String dni, String nombre, String edadStr, String seguro) throws Exception {
        if (dni.trim().isEmpty() || nombre.trim().isEmpty() || edadStr.trim().isEmpty()) {
            throw new Exception("Todos los campos personales son obligatorios.");
        }
        if (gestion.buscarPacientePorDni(dni).isPresent()) {
            throw new Exception("El paciente con este DNI ya existe.");
        }
        int edad = Integer.parseInt(edadStr);
        Paciente nuevo = new Paciente(dni, nombre, edad, seguro);
        gestion.registrarPaciente(nuevo);
    }

    /**
     * Corrige los datos de un paciente ya registrado (por ejemplo, un error de digitación).
     * Valida todo antes de aplicar nada: si algún dato es inválido, el paciente queda como estaba.
     */
    public void modificarPaciente(String dniActual, String dniNuevo, String nombreNuevo, String edadNueva, String seguroNuevo) throws Exception {
        Paciente paciente = gestion.buscarPacientePorDni(dniActual)
                .orElseThrow(() -> new Exception("Paciente no encontrado."));

        String dni = (dniNuevo == null) ? "" : dniNuevo.trim();
        String nombre = (nombreNuevo == null) ? "" : nombreNuevo.trim();
        String edadTexto = (edadNueva == null) ? "" : edadNueva.trim();

        if (dni.isEmpty() || nombre.isEmpty() || edadTexto.isEmpty()) {
            throw new Exception("Todos los campos personales son obligatorios.");
        }
        if (!dni.equals(dniActual) && gestion.buscarPacientePorDni(dni).isPresent()) {
            throw new Exception("Ya existe otro paciente con ese DNI.");
        }
        int edad;
        try {
            edad = Integer.parseInt(edadTexto);
        } catch (NumberFormatException e) {
            throw new Exception("La edad debe ser un número entero.");
        }
        if (edad < 0 || edad > 120) {
            throw new Exception("La edad debe estar entre 0 y 120 años.");
        }
        if (!Arrays.asList(SEGUROS_VALIDOS).contains(seguroNuevo)) {
            throw new Exception("Tipo de seguro no válido.");
        }

        paciente.actualizarDatos(dni, nombre, edad, seguroNuevo);
    }

    public void agendarCita(String dni, String tipo, String diagnostico, String especialidad, String doctor, LocalDate fecha) throws Exception {
        if (diagnostico.trim().isEmpty() || doctor.trim().isEmpty()) {
            throw new Exception("Debe ingresar un diagnóstico/motivo y asignar un doctor.");
        }
        if (!directorio.atiendeEspecialidad(doctor, especialidad)) {
            throw new Exception("El doctor seleccionado no atiende la especialidad indicada.");
        }
        if (fecha == null) {
            throw new Exception("Debe indicar la fecha de la cita.");
        }
        if (fecha.isBefore(LocalDate.now())) {
            throw new Exception("La fecha de la cita no puede ser anterior a la fecha actual.");
        }
        Paciente paciente = gestion.buscarPacientePorDni(dni)
                .orElseThrow(() -> new Exception("Paciente no encontrado. Regístrelo primero."));

        AtencionMedica nuevaCita = AtencionFactory.crearAtencion(tipo, diagnostico, especialidad, doctor, fecha);
        paciente.agregarAtencion(nuevaCita);
    }

    public GestionEstablecimiento getGestion() { return gestion; }
    public DirectorioMedico getDirectorio() { return directorio; }
}
