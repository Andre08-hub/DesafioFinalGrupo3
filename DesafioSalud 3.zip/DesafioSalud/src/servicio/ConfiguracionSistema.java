package servicio;

/**
 * Singleton con la configuración general del sistema.
 */
public class ConfiguracionSistema {
    private static ConfiguracionSistema instancia;
    private final String nombreEstablecimiento = "Centro de Salud Rural Santa Rosa";

    private ConfiguracionSistema() {}

    public static ConfiguracionSistema getInstancia() {
        if (instancia == null) {
            instancia = new ConfiguracionSistema();
        }
        return instancia;
    }

    public String getNombreEstablecimiento() {
        return nombreEstablecimiento;
    }
}
