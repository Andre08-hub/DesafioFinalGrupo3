package vista;

import javax.swing.*;
import java.awt.*;

import servicio.ConfiguracionSistema;
import servicio.GestionEstablecimiento;
import servicio.RegistroAtencionService;

public class LoginGUI extends JFrame {
    private static final long serialVersionUID = 1L;

    private int intentosFallidos = 0;
    private final int MAX_INTENTOS = 3;

    public LoginGUI() {
        // Vincula el título con el Singleton de configuración
        setTitle("Acceso Seguro - " + ConfiguracionSistema.getInstancia().getNombreEstablecimiento());
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
        setLayout(new GridLayout(4, 1, 10, 10)); // 4 filas, 1 columna

        JPanel pnlUser = new JPanel();
        pnlUser.add(new JLabel("Usuario:"));
        JTextField txtUser = new JTextField(15);
        pnlUser.add(txtUser);

        JPanel pnlPass = new JPanel();
        pnlPass.add(new JLabel("Clave:"));
        JPasswordField txtPass = new JPasswordField(15);
        pnlPass.add(txtPass);

        JButton btnLogin = new JButton("Ingresar");
        JLabel lblMensaje = new JLabel("Intentos restantes: 3", SwingConstants.CENTER);
        lblMensaje.setForeground(Color.RED);

        btnLogin.addActionListener(e -> {
            String usuario = txtUser.getText();
            String clave = new String(txtPass.getPassword());

            // Validación estructurada de credenciales
            if (usuario.equals("Grupo3") && clave.equals("Lenguaje")) {
                JOptionPane.showMessageDialog(this, "Acceso concedido.");
                this.dispose(); // Destruye la ventana de login

                // Instancia e inicia la ventana principal inyectando las dependencias
                new MainGUI(new RegistroAtencionService(new GestionEstablecimiento())).setVisible(true);
            } else {
                intentosFallidos++;
                int restantes = MAX_INTENTOS - intentosFallidos;

                if (restantes <= 0) {
                    JOptionPane.showMessageDialog(this, "Límite de intentos excedido. Sistema bloqueado.", "Error de Seguridad", JOptionPane.ERROR_MESSAGE);
                    System.exit(0); // Cierra la aplicación de forma segura
                } else {
                    lblMensaje.setText("Credenciales incorrectas. Intentos restantes: " + restantes);
                }
            }
        });

        add(pnlUser);
        add(pnlPass);
        add(btnLogin);
        add(lblMensaje);
    }
}
