package vista;

import javax.swing.SwingUtilities;


//Punto de arranque de la aplicación.

public class SistemaSaludRural {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginGUI login = new LoginGUI();
            login.setVisible(true);
        });
    }
}
