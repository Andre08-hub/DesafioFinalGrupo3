package vista;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import modelo.AtencionMedica;
import modelo.Doctor;
import modelo.Paciente;
import servicio.ConfiguracionSistema;
import servicio.CriterioBusqueda;
import servicio.RegistroAtencionService;

public class MainGUI extends JFrame {
    private static final long serialVersionUID = 1L;

    private RegistroAtencionService service;
    private DefaultTableModel modeloTabla;
    private JTable tablaPacientes;
    private JTextField txtBuscar;
    private JComboBox<CriterioBusqueda> cbCriterio;
    private JLabel lblResultados;

    public MainGUI(RegistroAtencionService service) {
        this.service = service;
        setTitle("Sistema Médico - Centro de Salud Rural Santa Esperanza");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // MENÚ SUPERIOR (Proyecto / Integrantes)
        setJMenuBar(crearMenuSuperior());

        JTabbedPane tabbedPane = new JTabbedPane();

        //REGISTRO DE PACIENTE
        tabbedPane.addTab("1. Registrar Paciente", crearPanelRegistroPaciente());

        //agendar cita con especialidad
        tabbedPane.addTab("2. Agendar Cita", crearPanelAgendarCita());

        //VER REGISTROS Y ELIMINAR
        tabbedPane.addTab("3. Registros de Pacientes", crearPanelRegistros());

        getContentPane().add(tabbedPane);

        // Listener para actualizar la tabla al cambiar de pestaña
        tabbedPane.addChangeListener(e -> actualizarTabla());
    }

    private JPanel crearPanelRegistroPaciente() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextField txtDni = new JTextField();
        JTextField txtNombre = new JTextField();
        JTextField txtEdad = new JTextField();
        JComboBox<String> cbSeguro = new JComboBox<>(RegistroAtencionService.SEGUROS_VALIDOS);
        JButton btnGuardar = new JButton("Registrar Paciente");

        panel.add(new JLabel("DNI: ")); panel.add(txtDni);
        panel.add(new JLabel("Nombre Completo:")); panel.add(txtNombre);
        panel.add(new JLabel("Edad:")); panel.add(txtEdad);
        panel.add(new JLabel("Tipo de Seguro:")); panel.add(cbSeguro);
        panel.add(new JLabel("")); panel.add(btnGuardar);

        btnGuardar.addActionListener(e -> {
            try {
                service.registrarNuevoPaciente(txtDni.getText(), txtNombre.getText(), txtEdad.getText(), cbSeguro.getSelectedItem().toString());
                JOptionPane.showMessageDialog(this, "Paciente registrado correctamente.");
                txtDni.setText(""); txtNombre.setText(""); txtEdad.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error estructurado", JOptionPane.ERROR_MESSAGE);
            }
        });
        return panel;
    }

    private JPanel crearPanelAgendarCita() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextField txtDniBuscar = new JTextField();
        JComboBox<String> cbTipo = new JComboBox<>(new String[]{"CONSULTA", "EMERGENCIA", "CONTROL CRED"});
        JComboBox<String> cbEspecialidad = new JComboBox<>(service.getDirectorio().getEspecialidades().toArray(new String[0]));
        JComboBox<Doctor> cbDoctor = new JComboBox<>();
        JSpinner spFecha = crearSelectorFecha();
        JTextField txtDiagnostico = new JTextField();
        JButton btnAgendar = new JButton("Agendar Cita");

        // Los doctores disponibles dependen de la especialidad elegida
        cargarDoctores(cbDoctor, cbEspecialidad.getSelectedItem().toString());
        cbEspecialidad.addActionListener(e -> cargarDoctores(cbDoctor, cbEspecialidad.getSelectedItem().toString()));

        panel.add(new JLabel("DNI del Paciente:")); panel.add(txtDniBuscar);
        panel.add(new JLabel("Tipo de Atención:")); panel.add(cbTipo);
        panel.add(new JLabel("Especialidad Requerida:")); panel.add(cbEspecialidad);
        panel.add(new JLabel("Doctor:")); panel.add(cbDoctor);
        panel.add(new JLabel("Fecha de la Cita (dd/MM/aaaa):")); panel.add(spFecha);
        panel.add(new JLabel("Motivo / Diagnóstico:")); panel.add(txtDiagnostico);
        panel.add(new JLabel("")); panel.add(btnAgendar);

        btnAgendar.addActionListener(e -> {
            try {
                Object doctorElegido = cbDoctor.getSelectedItem();
                if (doctorElegido == null) {
                    throw new Exception("Debe ingresar un diagnóstico/motivo y asignar un doctor.");
                }
                LocalDate fecha = obtenerFecha(spFecha);

                service.agendarCita(
                    txtDniBuscar.getText(),
                    cbTipo.getSelectedItem().toString(),
                    txtDiagnostico.getText(),
                    cbEspecialidad.getSelectedItem().toString(),
                    doctorElegido.toString(),
                    fecha
                );
                JOptionPane.showMessageDialog(this, "Cita médica agendada exitosamente para el "
                        + fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " con " + doctorElegido + ".");
                txtDiagnostico.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al agendar", JOptionPane.ERROR_MESSAGE);
            }
        });
        return panel;
    }

    // Rellena el combo de doctores con los que atienden la especialidad indicada.
    private void cargarDoctores(JComboBox<Doctor> cbDoctor, String especialidad) {
        cbDoctor.removeAllItems();
        service.getDirectorio().getDoctoresPorEspecialidad(especialidad).forEach(cbDoctor::addItem);
    }

    //Selector de fecha que no permite elegir días anteriores a hoy. 
    private JSpinner crearSelectorFecha() {
        Date hoyInicio = Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant());
        SpinnerDateModel modelo = new SpinnerDateModel(new Date(), hoyInicio, null, Calendar.DAY_OF_MONTH);
        JSpinner spinner = new JSpinner(modelo);
        spinner.setEditor(new JSpinner.DateEditor(spinner, "dd/MM/yyyy"));
        return spinner;
    }

    private LocalDate obtenerFecha(JSpinner spinner) {
        Date fecha = (Date) spinner.getValue();
        return fecha.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    private JPanel crearPanelRegistros() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        //Barra de búsqueda 
        cbCriterio = new JComboBox<>(CriterioBusqueda.values());
        txtBuscar = new JTextField() {
            private static final long serialVersionUID = 1L;

            // Texto de ayuda en gris mientras el campo está vacío
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getText().isEmpty()) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    g2.setColor(Color.GRAY);
                    FontMetrics fm = g2.getFontMetrics();
                    int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                    g2.drawString("Escriba para filtrar la tabla...", getInsets().left + 2, y);
                    g2.dispose();
                }
            }
        };
        txtBuscar.setToolTipText("Puede escribir varias palabras (todas deben coincidir). No distingue mayúsculas ni tildes.");
        JButton btnLimpiar = new JButton("Limpiar");

        JPanel pnlCriterio = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        pnlCriterio.add(new JLabel("Buscar por:"));
        pnlCriterio.add(cbCriterio);

        JPanel pnlBusqueda = new JPanel(new BorderLayout(8, 0));
        pnlBusqueda.add(pnlCriterio, BorderLayout.WEST);
        pnlBusqueda.add(txtBuscar, BorderLayout.CENTER);
        pnlBusqueda.add(btnLimpiar, BorderLayout.EAST);

        // ---------- Tabla ----------
        modeloTabla = new DefaultTableModel(new String[]{"DNI", "Nombre", "Edad", "Seguro", "Próxima Cita", "N° Citas"}, 0) {
            private static final long serialVersionUID = 1L;

            // DNI, Nombre, Edad y Seguro se pueden corregir;
            @Override
            public boolean isCellEditable(int fila, int columna) { return columna <= 3; }

            // Al terminar de editar una celda, el cambio se guarda en el paciente (con validaciones).
            // Si el dato no es válido se muestra el motivo y la celda conserva su valor anterior.
            @Override
            public void setValueAt(Object valor, int fila, int columna) {
                if (columna > 3) {
                    super.setValueAt(valor, fila, columna);
                    return;
                }
                String texto = (valor == null) ? "" : valor.toString().trim();
                if (texto.equals(String.valueOf(getValueAt(fila, columna)))) {
                    return; // sin cambios
                }
                String[] datos = new String[4]; // DNI, Nombre, Edad, Seguro de la fila
                for (int c = 0; c < datos.length; c++) {
                    datos[c] = String.valueOf(getValueAt(fila, c));
                }
                String dniActual = datos[0];
                datos[columna] = texto;
                try {
                    service.modificarPaciente(dniActual, datos[0], datos[1], datos[2], datos[3]);
                    super.setValueAt(columna == 2 ? (Object) Integer.valueOf(texto) : texto, fila, columna);
                } catch (Exception ex) {
                    mostrarError("No se pudo modificar el paciente", ex.getMessage());
                }
            }

            // El tipo de cada columna permite ordenar bien números y fechas al hacer clic en el encabezado
            @Override
            public Class<?> getColumnClass(int columna) {
                switch (columna) {
                    case 2: case 5: return Integer.class;
                    case 4:         return LocalDate.class;
                    default:        return String.class;
                }
            }
        };
        tablaPacientes = new JTable(modeloTabla);
        configurarEstiloTabla(tablaPacientes);
        JScrollPane scrollPane = new JScrollPane(tablaPacientes);

        // ---------- Botones ----------
        JButton btnVerCitas = new JButton("Ver Citas del Paciente Seleccionado");

        JButton btnEliminar = new JButton("Eliminar Paciente Seleccionado");
        btnEliminar.setBackground(new Color(220, 50, 50));
        btnEliminar.setForeground(Color.RED);

        btnVerCitas.addActionListener(e -> {
            String dni = dniSeleccionado();
            if (dni != null) {
                service.getGestion().buscarPacientePorDni(dni).ifPresent(this::mostrarCitas);
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un paciente de la tabla para ver sus citas.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            String dniSeleccionado = dniSeleccionado();
            if (dniSeleccionado != null) {
                int confirmacion = JOptionPane.showConfirmDialog(this, "¿Seguro que desea eliminar al paciente con DNI " + dniSeleccionado + "?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (confirmacion == JOptionPane.YES_OPTION) {
                    if (service.getGestion().eliminarPaciente(dniSeleccionado)) {
                        JOptionPane.showMessageDialog(this, "Paciente eliminado.");
                        actualizarTabla();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un paciente de la tabla para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });

        JPanel pnlBotones = new JPanel(new GridLayout(1, 2, 10, 0));
        pnlBotones.add(btnVerCitas);
        pnlBotones.add(btnEliminar);

        lblResultados = new JLabel(" ");
        lblResultados.setForeground(Color.DARK_GRAY);
        JLabel lblAyuda = new JLabel("Doble clic en DNI, Nombre, Edad o Seguro para corregirlo");
        lblAyuda.setForeground(Color.GRAY);

        JPanel pnlInfo = new JPanel(new BorderLayout());
        pnlInfo.add(lblResultados, BorderLayout.WEST);
        pnlInfo.add(lblAyuda, BorderLayout.EAST);

        JPanel pnlSur = new JPanel(new BorderLayout(0, 8));
        pnlSur.add(pnlInfo, BorderLayout.NORTH);
        pnlSur.add(pnlBotones, BorderLayout.CENTER);

        panel.add(pnlBusqueda, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(pnlSur, BorderLayout.SOUTH);

        //Filtrado en vivo: cada tecla o cambio de criterio vuelve a filtrar 
        txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e)  { actualizarTabla(); }
            @Override public void removeUpdate(DocumentEvent e)  { actualizarTabla(); }
            @Override public void changedUpdate(DocumentEvent e) { actualizarTabla(); }
        });
        cbCriterio.addActionListener(e -> actualizarTabla());
        btnLimpiar.addActionListener(e -> {
            txtBuscar.setText("");
            cbCriterio.setSelectedItem(CriterioBusqueda.TODOS);
            txtBuscar.requestFocusInWindow();
        });

        actualizarTabla();
        return panel;
    }

    //Aspecto de la tabla: filas alternadas, encabezado en negrita, columnas con ancho y alineación.
    private void configurarEstiloTabla(JTable tabla) {
        tabla.setRowHeight(26);
        tabla.setShowVerticalLines(false);
        tabla.setGridColor(new Color(225, 228, 232));
        tabla.setSelectionBackground(new Color(70, 130, 180));
        tabla.setSelectionForeground(Color.WHITE);
        tabla.setFillsViewportHeight(true);
        tabla.setAutoCreateRowSorter(true); // clic en un encabezado para ordenar
        tabla.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE); // al salir de la celda se guarda lo escrito

        // Edad: campo de texto (el servicio valida que sea un número); Seguro: lista con las opciones permitidas
        JTextField txtEdadEditor = new JTextField();
        txtEdadEditor.setHorizontalAlignment(SwingConstants.CENTER);
        tabla.getColumnModel().getColumn(2).setCellEditor(new DefaultCellEditor(txtEdadEditor));
        tabla.getColumnModel().getColumn(3).setCellEditor(
                new DefaultCellEditor(new JComboBox<>(RegistroAtencionService.SEGUROS_VALIDOS)));

        RenderizadorTabla renderizador = new RenderizadorTabla();
        tabla.setDefaultRenderer(Object.class, renderizador);
        tabla.setDefaultRenderer(Number.class, renderizador);

        JTableHeader cabecera = tabla.getTableHeader();
        cabecera.setFont(cabecera.getFont().deriveFont(Font.BOLD));
        cabecera.setReorderingAllowed(false);

        int[] anchos = {90, 230, 50, 90, 110, 70};
        for (int i = 0; i < anchos.length; i++) {
            tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }
    }

    // DNI del paciente seleccionado, o null si no hay selección. Convierte el índice de la vista al del modelo (hay orden y filtro).
    private String dniSeleccionado() {
        int fila = tablaPacientes.getSelectedRow();
        if (fila < 0) return null;
        return modeloTabla.getValueAt(tablaPacientes.convertRowIndexToModel(fila), 0).toString();
    }

    private void mostrarCitas(Paciente p) {
        List<AtencionMedica> citas = p.getHistorial();
        String texto = citas.isEmpty()
                ? "Este paciente aún no tiene citas registradas."
                : citas.stream().map(AtencionMedica::getDetalle).collect(Collectors.joining("\n"));

        JTextArea area = new JTextArea(texto, 10, 50);
        area.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(area),
                "Citas de " + p.getNombreCompleto(), JOptionPane.INFORMATION_MESSAGE);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0); // Limpiar tabla

        int total = service.getGestion().getPacientes().size();
        // Búsqueda con Streams (ver GestionEstablecimiento.buscarPacientes)
        List<Paciente> lista = service.getGestion()
                .buscarPacientes(txtBuscar.getText(), (CriterioBusqueda) cbCriterio.getSelectedItem());

        // Procesamiento funcional de datos
        lista.forEach(p -> {
            modeloTabla.addRow(new Object[]{
                p.getDniDesencriptado(),
                p.getNombreCompleto(),
                p.getEdad(),
                p.getSeguro(),
                p.getProximaCita().orElse(null),
                p.getHistorial().size()
            });
        });

        String sufijo = (total == 1) ? " paciente" : " pacientes";
        lblResultados.setText(lista.isEmpty() && total > 0
                ? "Sin coincidencias (0 de " + total + sufijo + ")"
                : "Mostrando " + lista.size() + " de " + total + sufijo);
    }

    // Muestra un mensaje de error. Es un método aparte para poder reutilizarlo desde cualquier parte de la ventana. 
    protected void mostrarError(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.ERROR_MESSAGE);
    }

    // MENÚ SUPERIOR E INTEGRANTES 

    // Datos de un integrante del equipo 
    private static class Integrante {
        final String menu;
        final String nombre;
        final String codigo;
        final String foto;

        Integrante(String menu, String nombre, String codigo, String foto) {
            this.menu = menu;
            this.nombre = nombre;
            this.codigo = codigo;
            this.foto = foto;
        }
    }

    private static final Integrante[] INTEGRANTES = {
        new Integrante("Andree", "Andre Alonzo Mogollón Almidón", "N00523964",  "/imagenes/Andre2.0.jpg"),
        new Integrante("Erick",  "Erick Antony Campos Gilvonio",  "N00543319", "/imagenes/Erick2.0.jpg"),
        new Integrante("John",   "John Mario Sanchez Chigne",     "N00533225", "/imagenes/John3.0.png"),
        new Integrante("Yamile", "Yamile Cancino Yaipen",         "N00531127", "/imagenes/yamile2.0.jpg"),
        new Integrante("Oskar", "Oskar Mauricio Soto Córdova",    "N00534390", "/imagenes/oskar2.0.jpg"),
    };

    private JMenuBar crearMenuSuperior() {
        JMenuBar barra = new JMenuBar();

        JMenu mnuProyecto = new JMenu("Proyecto");
        JMenuItem itemAcerca = new JMenuItem("Acerca del proyecto");
        itemAcerca.addActionListener(e -> JOptionPane.showMessageDialog(this, crearPanelAcerca(),
                "Acerca del proyecto", JOptionPane.PLAIN_MESSAGE));
        mnuProyecto.add(itemAcerca);

        JMenu mnuIntegrantes = new JMenu("Integrantes");
        for (Integrante integrante : INTEGRANTES) {
            JMenuItem item = new JMenuItem(integrante.menu);
            item.addActionListener(e -> mostrarIntegrante(integrante));
            mnuIntegrantes.add(item);
        }

        barra.add(mnuProyecto);
        barra.add(mnuIntegrantes);
        return barra;
    }

    // Abre la ventana con la foto y los datos del integrante.
    private void mostrarIntegrante(Integrante integrante) {
        JDialog dialogo = new JDialog(this, "Integrante - " + integrante.menu, false);
        dialogo.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialogo.setContentPane(crearPanelIntegrante(integrante));
        dialogo.pack();
        dialogo.setLocationRelativeTo(this);
        dialogo.setVisible(true);
    }

    private JPanel crearPanelIntegrante(Integrante integrante) {
        JPanel panel = new JPanel(new BorderLayout(15, 0));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel lblFoto = new JLabel(cargarIcono(integrante.foto));
        lblFoto.setVerticalAlignment(SwingConstants.TOP);

        JLabel lblNombre = new JLabel(integrante.nombre);
        lblNombre.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
        JLabel lblCodigo = new JLabel("Código: " + integrante.codigo);
        lblCodigo.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
        JLabel lblParticipacion = new JLabel("Participacion = 100%");
        lblParticipacion.setFont(new Font("Lucida Grande", Font.PLAIN, 14));

        JPanel datos = new JPanel();
        datos.setLayout(new BoxLayout(datos, BoxLayout.Y_AXIS));
        for (JLabel etiqueta : new JLabel[]{lblNombre, lblCodigo, lblParticipacion}) {
            etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);
            etiqueta.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
            datos.add(etiqueta);
        }

        panel.add(lblFoto, BorderLayout.WEST);
        panel.add(datos, BorderLayout.CENTER);
        return panel;
    }

    // Título y foto del centro de salud
    private JPanel crearPanelAcerca() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));

        JLabel lblTitulo = new JLabel("Proyecto Centro de Salud Santa Esperanza", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("SignPainter", Font.PLAIN, 27));

        panel.add(lblTitulo, BorderLayout.NORTH);
        panel.add(new JLabel(cargarIcono("/imagenes/centrosalud.jpeg"), SwingConstants.CENTER), BorderLayout.CENTER);
        return panel;
    }

    // Carga una imagen del paquete de recursos; si no existe devuelve null en vez de fallar.
    private ImageIcon cargarIcono(String ruta) {
        URL url = MainGUI.class.getResource(ruta);
        return (url == null) ? null : new ImageIcon(url);
    }

    // Dibuja las celdas: filas alternadas, fechas dd/MM/aaaa
    private static class RenderizadorTabla extends DefaultTableCellRenderer {
        private static final long serialVersionUID = 1L;
        private static final Color FILA_ALTERNA = new Color(244, 247, 251);
        private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        @Override
        public Component getTableCellRendererComponent(JTable tabla, Object valor, boolean seleccionada,
                                                       boolean conFoco, int fila, int columna) {
            super.getTableCellRendererComponent(tabla, valor, seleccionada, false, fila, columna);
            if (valor == null) {
                setText("—");
            } else if (valor instanceof LocalDate) {
                setText(((LocalDate) valor).format(FORMATO_FECHA));
            }
            setHorizontalAlignment(valor instanceof String ? SwingConstants.LEFT : SwingConstants.CENTER);
            setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
            if (!seleccionada) {
                setBackground(fila % 2 == 0 ? Color.WHITE : FILA_ALTERNA);
            }
            return this;
        }
    }
}
