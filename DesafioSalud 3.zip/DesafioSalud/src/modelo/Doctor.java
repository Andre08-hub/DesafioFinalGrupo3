package modelo;

/**
 * Profesional de salud del establecimiento. Cada doctor pertenece a una especialidad.
 */
public class Doctor {
    private final String titulo;        // "Dr.", "Dra." o "Lic."
    private final String nombreCompleto;
    private final String especialidad;

    public Doctor(String titulo, String nombreCompleto, String especialidad) {
        this.titulo = titulo;
        this.nombreCompleto = nombreCompleto;
        this.especialidad = especialidad;
    }

    public String getTitulo() { return titulo; }
    public String getNombreCompleto() { return nombreCompleto; }
    public String getEspecialidad() { return especialidad; }

    /** Nombre tal como se muestra en pantalla y se guarda en la cita, ej. "Dra. Rosa Mendoza Tello". */
    public String getNombreConTitulo() {
        return titulo + " " + nombreCompleto;
    }

    @Override
    public String toString() {
        return getNombreConTitulo();
    }
}
