package modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AtencionMedica {
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private String tipo;
    private String diagnostico;
    private String especialidad;
    private String doctor;
    private LocalDate fecha;
    private double costo;

    public AtencionMedica(String tipo, String diagnostico, String especialidad, String doctor, LocalDate fecha, double costo) {
        this.tipo = tipo;
        this.diagnostico = diagnostico;
        this.especialidad = especialidad;
        this.doctor = doctor;
        this.fecha = fecha;
        this.costo = costo;
    }

    public String getDetalle() {
        return fecha.format(FORMATO_FECHA) + " | " + tipo + " - " + especialidad + " (" + doctor + "): " + diagnostico;
    }

    public LocalDate getFecha() { return fecha; }
    public double getCosto() { return costo; }
}
