package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class Paciente extends Persona {
    private String seguro;
    private List<AtencionMedica> historialAtenciones;

    public Paciente(String dni, String nombreCompleto, int edad, String seguro) {
        super(dni, nombreCompleto, edad);
        this.seguro = seguro;
        this.historialAtenciones = new ArrayList<>();
    }

    public String getSeguro() { return seguro; }
    public List<AtencionMedica> getHistorial() { return historialAtenciones; }

    public void agregarAtencion(AtencionMedica atencion) {
        historialAtenciones.add(atencion);
    }

    /** Corrige los datos del paciente. El historial de atenciones se conserva. */
    public void actualizarDatos(String dni, String nombreCompleto, int edad, String seguro) {
        actualizarDatosPersonales(dni, nombreCompleto, edad);
        this.seguro = seguro;
    }

    /** Fecha de la cita más cercana (hoy o posterior). Vacío si no tiene citas pendientes. */
    public Optional<LocalDate> getProximaCita() {
        LocalDate hoy = LocalDate.now();
        return historialAtenciones.stream()
                .map(AtencionMedica::getFecha)
                .filter(fecha -> !fecha.isBefore(hoy))
                .min(Comparator.naturalOrder());
    }
}
