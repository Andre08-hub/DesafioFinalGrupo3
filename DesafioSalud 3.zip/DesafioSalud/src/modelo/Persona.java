package modelo;

/**
 * Clase base de las personas del sistema (POO y Herencia).
 */
public abstract class Persona {
    protected String dniHash; // Cifrado simple para cumplir Ley 29733
    protected String nombreCompleto;
    protected int edad;

    public Persona(String dni, String nombreCompleto, int edad) {
        this.dniHash = encriptarDni(dni);
        this.nombreCompleto = nombreCompleto;
        this.edad = edad;
    }

    // Simulador de hash para el DNI
    private String encriptarDni(String dni) {
        return "ENCRYPT-" + dni;
    }

    public String getDniDesencriptado() {
        return dniHash.replace("ENCRYPT-", "");
    }

    public String getNombreCompleto() { return nombreCompleto; }
    public int getEdad() { return edad; }

    /** Corrige los datos personales (el DNI se vuelve a cifrar). */
    protected void actualizarDatosPersonales(String dni, String nombreCompleto, int edad) {
        this.dniHash = encriptarDni(dni);
        this.nombreCompleto = nombreCompleto;
        this.edad = edad;
    }
}
